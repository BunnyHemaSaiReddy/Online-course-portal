firebase_config = {
    "apiKey": "AIzaSyA_dvNAf19mcXXdLZjoHsgC8SmmLKcbKKg",
    "authDomain": "signup-login-b28f5.firebaseapp.com",
    "databaseURL": "",  # Optional: you can leave this blank if not using Realtime DB
    "projectId": "signup-login-b28f5",
    "storageBucket": "signup-login-b28f5.appspot.com",
    "messagingSenderId": "946139293369",
    "appId": "1:946139293369:web:25c7ab86146ec144a35d68"
}
