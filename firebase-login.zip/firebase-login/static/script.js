document.addEventListener("DOMContentLoaded", () => {
    const firebaseConfig = {
      apiKey: "AIzaSyA_dvNAf19mcXXdLZjoHsgC8SmmLKcbKKg",
      authDomain: "signup-login-b28f5.firebaseapp.com",
      projectId: "signup-login-b28f5",
      storageBucket: "signup-login-b28f5.appspot.com",
      messagingSenderId: "946139293369",
      appId: "1:946139293369:web:25c7ab86146ec144a35d68",
      measurementId: "G-FQ8CE9TTK0"
    };
    
    firebase.initializeApp(firebaseConfig);
    const auth = firebase.auth();
    const errorMsg = document.getElementById("error-msg");
    
    // Google Sign-In
    document.getElementById("googleSignInBtn").addEventListener("click", () => {
      const provider = new firebase.auth.GoogleAuthProvider();
      auth.signInWithPopup(provider)
        .then(result => result.user.getIdToken())
        .then(idToken => {
          return fetch('/google-log', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ idToken })
          });
        })
        .then(response => response.json())
        .then(data => {
          if (data.redirect) {
            window.location.href = data.redirect;
          } else {
            errorMsg.textContent = data.error || "Google login failed. Please try again.";
          }
        })
        .catch(error => {
          errorMsg.textContent = `Google Login Error: ${error.message}`;
          console.error(error);
        });
    });
    
    // Facebook Sign-In
    document.getElementById("facebookSignInBtn").addEventListener("click", () => {
      const provider = new firebase.auth.FacebookAuthProvider();
      auth.signInWithPopup(provider)
        .then(result => {
          // For Facebook, obtain the access token instead of ID token
          const accessToken = result.credential.accessToken;
          return fetch('/facebook-login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ accessToken })
          });
        })
        .then(response => response.json())
        .then(data => {
          if (data.redirect) {
            window.location.href = data.redirect;
          } else {
            errorMsg.textContent = data.error || "Facebook login failed. Please try again.";
          }
        })
        .catch(error => {
          errorMsg.textContent = `Facebook Login Error: ${error.message}`;
          console.error(error);
        });
    });
  });