document.addEventListener("DOMContentLoaded", function () {
    loadChatHistory();
});

async function sendMessage() {
    const userInput = document.getElementById("userInput");
    const message = userInput.value.trim();

    // Get the uploaded image file
    const imageInput = document.getElementById("imageInput");
    const imageFile = imageInput.files[0];

    if (!message && !imageFile) {
        alert("Please enter a message or upload an image!");
        return;
    }

    // Display user message (question first)
    appendMessage(message, "user-message", "left");

    // Show loading animation (. . .)
    const loadingMessage = appendMessage("...", "loading-message", "right");

    // Prepare the form data (message + image file if present)
    const formData = new FormData();
    formData.append("prompt", message);
    
    if (imageFile) {
        formData.append("image", imageFile);
    }

    fetch("/generate", {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(async (data) => {
        if (data.response) {
            // Remove loading message
            loadingMessage.remove();

            // Display AI response with typing effect
            await displayTypingEffect(data.response, "ai-message", "right");

            saveChatHistory(message, data.response);
        } else {
            alert("Error: " + data.error);
        }
    })
    .catch(error => console.error("Error:", error));

    // Clear input field
    userInput.value = "";
    imageInput.value = ""; // Clear the file input
}

function appendMessage(text, className, align) {
    const chatHistory = document.getElementById("chat-history");
    const messageDiv = document.createElement("div");
    messageDiv.classList.add("message", className, align);
    
    // Format text (bold for headings, code highlighting)
    messageDiv.innerHTML = formatResponseText(text);
    
    chatHistory.appendChild(messageDiv);
    chatHistory.scrollTop = chatHistory.scrollHeight;  // Auto-scroll to latest message

    return messageDiv; // Return the message div for deletion (used for loading message)
}

async function displayTypingEffect(text, className, align) {
    const chatHistory = document.getElementById("chat-history");
    const messageDiv = document.createElement("div");
    messageDiv.classList.add("message", className, align);
    
    chatHistory.appendChild(messageDiv);
    chatHistory.scrollTop = chatHistory.scrollHeight;

    let formattedText = formatResponseText(text);
    let tempHTML = "";  // Store intermediate HTML output
    let insideTag = false;  // Track whether we are inside an HTML tag

    for (let char of formattedText) {
        if (char === "<") insideTag = true;
        if (!insideTag) {
            tempHTML += char;
            messageDiv.innerHTML = tempHTML; // Update message div
            await sleep(20);  // Typing effect delay
        } else {
            tempHTML += char;
        }
        if (char === ">") {
            insideTag = false;
            messageDiv.innerHTML = tempHTML; // Render full HTML tag properly
        }
        chatHistory.scrollTop = chatHistory.scrollHeight; // Keep scrolling down
    }
}


// Save chat history to localStorage
function saveChatHistory(userMessage, aiResponse) {
    // Retrieve existing chat history from localStorage
    let chatHistory = JSON.parse(localStorage.getItem("chatHistory")) || [];
    
    // Add new user message and AI response to the history
    chatHistory.push({ user: userMessage, ai: aiResponse });
    
    // Save the updated history back to localStorage
    localStorage.setItem("chatHistory", JSON.stringify(chatHistory));
}

// Load chat history from localStorage
function loadChatHistory() {
    // Retrieve chat history from localStorage
    const chatHistory = JSON.parse(localStorage.getItem("chatHistory")) || [];

    // Iterate through each saved chat and append it to the UI
    chatHistory.forEach(chat => {
        appendMessage(chat.user, "user-message", "left");
        appendMessage(chat.ai, "ai-message", "right");
    });
}

// Format AI response for better readability (bold and code highlighting)
function formatResponseText(text) {
    return text
        .replace(/\*\*(.*?)\*\*/g, "<b>$1</b>")  // **Bold** text
        .replace(/```(.*?)```/gs, '<pre><code>$1</code></pre>')  // Code blocks
        .replace(/\n/g, "<br>");  // Preserve line breaks
}

// Sleep function for smooth typing effect
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}


// 🎤 Voice Input using Web Speech API
function startListening() {
    const userInput = document.getElementById("userInput");

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
        alert("Sorry, your browser does not support speech recognition.");
        return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = "en-US";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.start();

    recognition.onstart = () => {
        console.log("Listening...");
    };

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        console.log("You said:", transcript);
        userInput.value = transcript;
        sendMessage(); // auto-send after speech input
    };

    recognition.onerror = (event) => {
        console.error("Speech recognition error:", event.error);
        alert("Error: " + event.error);
    };
}
